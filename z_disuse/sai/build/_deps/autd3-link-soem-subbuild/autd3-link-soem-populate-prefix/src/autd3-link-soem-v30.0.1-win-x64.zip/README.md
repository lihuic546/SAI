# autd3-cpp-link-soem

![build](https://github.com/shinolab/autd3-cpp-link-soem/workflows/build/badge.svg)
[![codecov](https://codecov.io/gh/shinolab/autd3-cpp-link-soem/graph/badge.svg?precision=2)](https://codecov.io/gh/shinolab/autd3-cpp-link-soem)
[![release](https://img.shields.io/github/v/release/shinolab/autd3-cpp-link-soem)](https://github.com/shinolab/autd3-cpp-link-soem/releases/latest)

[autd3-link-soem](https://github.com/shinolab/autd3-link-soem) library for C++.

## LICENSE

* See [LICENSE](./LICENSE) and [ThirdPartyNotice](./ThirdPartyNotice.txt) for more information.

# Author

Shun Suzuki, 2022-2025
