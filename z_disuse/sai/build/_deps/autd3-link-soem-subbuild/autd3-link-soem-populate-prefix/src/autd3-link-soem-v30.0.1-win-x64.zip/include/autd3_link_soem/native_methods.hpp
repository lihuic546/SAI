#pragma once

#include <autd3/native_methods.hpp>

#include "autd3_link_soem/native_methods/autd3-link-soem.h"
// autd3-link-soem.h must be included first
#include "autd3_link_soem/native_methods/autd3-capi-link-soem.h"
