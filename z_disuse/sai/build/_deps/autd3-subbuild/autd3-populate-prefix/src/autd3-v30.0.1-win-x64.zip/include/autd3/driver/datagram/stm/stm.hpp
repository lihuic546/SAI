#pragma once

namespace autd3::driver {

struct NearestFreq final {};
struct NearestPeriod final {};

}  // namespace autd3::driver
