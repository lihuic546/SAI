#pragma once

namespace autd3::modulation {

struct Nearest final {};

}  // namespace autd3::modulation
